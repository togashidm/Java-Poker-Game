package application;


/*
 *  The class "Card" has the constructor that creates instances of card with a value and suit.
 *  The constructor takes String value and String suit; 
 *  
 */

public class Card {
	
	private String value;
	private String suit;
	
	
	/**
	 * Constructor that creates the card instance
	 * 
	 * @param value
	 * @param suit
	 */
	Card(String value, String suit){
		this.value=value.toUpperCase();			// make them all up case
		this.suit=suit.toUpperCase();			// make them all up case
	}
	
	
	 /**
     * toString() method return the card information as String composed by the value and 
     * suit in unicode format.   
     *  
     * @param: none
     * @return: the card value and suit in unicode as String.
     */	
	public String toString() {
		return value+toShape(suit);
	}

	/**
	 * getValue() method return the Card instance value to the caller
	 * 
	 * @param: none
	 * @return: String value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * getSuit() method return the Card instance suit to the caller
	 * 
	 * @param: none
	 * @return: String suit
	 */
	public String getSuit() {
		return suit;
	}

	
	 /**
     * toShape is a String method that return the proper suit shape 
     * in unicode. Please note that in Eclipse needs to be configured
     * to display those characters by:
     * 		Under "Run" on top menu, for each Run configuration
     * 		look for "Common" tab 
     * 		Under Console Encoding, select Other UTF-8
     *  
     * @param: String ext
     * @return: the String in the respective unicode, or "not defined" otherwise.
     */	
	public static String toShape(String ext) {
		switch (ext) {
		
		case "D":
			return "\u2666 ";

		case "H":
			return "\u2665 ";
			

		case "C":
			return "\u2663 ";
	
		case "S":
			return "\u2660 ";
		}
		return "not defined";
	}
	
	/**
	 * setSuit() method set the suit value from the caller
	 * 
	 * @param: String suit
	 * @return: none
	 */
	public void setSuit(String suit) {
		this.suit = suit;
	}
	
}
