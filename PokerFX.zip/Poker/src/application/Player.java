package application;

/**
 * Player class is a derived class from Deck. This class is related to the players that will play a poker game, therefore,
 * it is specific for this Game. 
 * 
 *  The instances created from this class has access to all the methods from the base Deck class and can call:
 *  
 *  boolean canOpen(Player player);
 *  int nCardsToDiscard(Player player);
 *    
 *    
 * 
 * @author Denisio
 *
 */

import java.util.ArrayList;

public class Player extends Deck{

	private Card [] hand;
	private int token;

	
	/**
	 * 
	 * @param hand
	 */
	public Player(Card [] hand) {
		this.token = 10;
		this.hand = hand;
	}

/**
 * Method that check if the hand has the minimum to start/open the game.
 * That is, need at least a pair of jacks.
 * 
 * @param hand
 * @return true if it can open the game, false otherwise.
 */
	public static boolean canOpen(Player player) {
		boolean open;
		
		open = PokerDeck.isFlush(Deck.sort(player.hand)) ||
				PokerDeck.isStraight(Deck.sort(player.hand)) ||
				PokerDeck.wantTokeep(player.getHand()).size() >2 ||
				PokerDeck.wantTokeep(player.getHand()).size()==2 &&
						//open for above pair of Jacks
				Integer.parseInt(replacement(PokerDeck.wantTokeep(player.getHand()).get(0)))>10; 						
		
		return	open;
	}
	
	
	/**
	 * Method that tell how many cards to replace the hand when it is need.
	 * for automatic selection
	 * 
	 * @param Player player
	 * @return max of 4 if it needs to discard 4, up to a minimum of 0.
	 */
	public static int nCardsToDiscard(Player player) {
		
		switch (PokerDeck.wantTokeep(player.getHand()).size()){
			case 4: return 1;
			case 3: return 2;
			case 2: return 3;
			default: 
				if (PokerDeck.isFlush(Deck.sort(player.hand)) ||
				PokerDeck.isStraight(Deck.sort(player.hand)))
					return 0;
				else
					return 4;
		}
	}
	

	/**
	 * method 'refresh' takes two parameter the instance created by the PokerDeck and the ArrayList of the cards
	 * that the player want to keep in the hand. It return them together with a new fresh cards to complete the hand, i.e, 5 cards.
	 * So, if the player want to keep 3 cards, those cards are return to the player with additional 2 cards from the original card 
	 * Deck created to dealer.   
	 *  	
	 * @param Deck dealer
	 * @param ArrayList <Card> wantToKeep
	 * @return Card[] with the cards that player want to keep plus other new cards to complete 5 cards on the hand.
	 */
	public static Card[] refresh(Deck dealer, ArrayList<Card> wantToKeep) {
			
			int n=5;
			int nk=wantToKeep.size();
			int numToDiscard = n - nk; 				// num of card to replace
			Card[] refreshedHand = new Card[n];  	// the new hand
			Card[] temp = new Card[numToDiscard];
			temp = dealer.getCards(numToDiscard);  
			for (int i=0; i<n; i++) {
				if (i < nk)	refreshedHand[i] = wantToKeep.get(i); 					// add the nk cards that player want to keep
				else {
					refreshedHand[i] = temp[i-nk]; 									// add n-nk  re shuffle cards from the deck
					}
				}
			return refreshedHand;		
		}


	
	/**
	 *  Method "keepMyCards" return a list of card that player wants to keep. Differently from the 'refresh' the player can
	 *  choose the card position at his/her hand to keep them and discards the remainder. The cards are ordered at position 1,
	 *  2, 3, 4, and 5. The values are passed as an array of integers.
	 *  
	 *  @parameter: Card [] hand 
	 *  @return:	ArrayList<Card>
	 */
	public static ArrayList<Card> keepMyCards(Card [] hand, int [] orderPosTokeep) {
		ArrayList<Card> myHand = new ArrayList<Card>(); 		// creates a ArrayList list of card to keep
		int k;													// variable for the index array index position
		for (int j=0; j<orderPosTokeep.length; j++ ) {
			k=orderPosTokeep[j];

			// Adding the cards values to the list
			for (int i=0; i<hand.length; i++) {
				if (i==k-1) myHand.add(hand[i]);				// taking into account the array index with the card position.
				}
			}		
		return myHand;
		}	

	
	
	/**
	 * Method "getHand" return the player hand, i.e. the array of Card
	 * 
	 * @return Card[] hand
	 */
	public Card[] getHand() {
		return hand;
	}
	
	/**
	 * Method "setHand" passes an array of Card to the player hand.
	 * 
	 * @param hand
	 */

	public void setHand(Card[] hand) {
		this.hand = hand;
	}
	
	
	/**
	 * Method "getToken" return the amount of tokens that the caller has.  
	 * If the caller does not have enough funds, it will throw an exception.
	 * 
	 * @return int token
	 * @throws Exception
	 */
	public int getToken() throws Exception {
		checkBalance(this.token);
		return token;
	}

	
	/**
	 * Method "setToken" set the amount of tokens of the caller. 
	 * 
	 * @param token
	 */
	public void setToken(int token) {
		this.token = token;
	}
	
	
	/**
	 * Method "putToken" reduced caller amount of the tokens that the caller is passing into the pot.
	 * If there is not enough tokens, it will throw an exception.
	 * 
	 * @param int token
	 * @throws Exception
	 */
	public void putToken(int token) throws Exception {
			checkBalance(this.token);
			this.token -= token;
		}
		
	/**
	 * Method "topUpToken" add an amount of tokens that the caller is passing.
	 * 
	 * @param int token
	 */
	public void topUpToken(int token) {
		this.token += token;
	}
	

	/**
	 * Method "checkBalance" will check if the the caller has enough funds, i.e., if it less or equal than 0,
	 * the method will throw an exception, otherwise the amount of the caller tokens.
	 * 
	 * @param int token
	 * @throws Exception
	 */
	public void checkBalance(int token) throws Exception {
		
		if(token <= 0)  throw new Exception("A player doesn't have balance to proceed");
	}

	
}
