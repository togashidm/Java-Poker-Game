package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;

public class MainController implements Initializable  {
		
/*
 * The following variables are the liking to the FXML 
 */
	@FXML
	private Label result;
	
	@FXML
	private Label cd1;
	
	@FXML
	private Label cd2;
	
	@FXML
	private Label cd3;
	
	@FXML
	private Label cd4;

	@FXML
	private Label cd5;
	
	@FXML
	private Label cp1;
	
	@FXML
	private Label cp2;
	
	@FXML
	private Label cp3;
	
	@FXML
	private Label cp4;

	@FXML
	private Label cp5;
	
	@FXML
	private Label p1Token;

	@FXML
	private Label p2Token;
	
	@FXML
	private Label pot;

	@FXML
	private CheckBox checkBox;
	
	@FXML
	private CheckBox cbc1;
	
	@FXML
	private CheckBox cbc2;
	
	@FXML
	private CheckBox cbc3;
	
	@FXML
	private CheckBox cbc4;
	
	@FXML
	private CheckBox cbc5;
	
	@FXML
	private Slider slider;
	
	
	private boolean player1CanWant, player2CanWant,	/* if the players can and want to open */ 
						lockRound, 						/* if the cards were dealt */
						refresh, 						/* if the cards were refreshed */
						foldQuestion, 					/* if player 2 want to proceed or to fold */ 
						roundEnd, 						/* if a round ended */
						previousTokens;					/* if tokens qty to carry from previous round */
	
	private PokerDeck dealer;	// instance dealer from Deck derived class with 10 tokens.
	private Player player1;		// dealer shuffle deck and assigns 5 of the cards to player1
	private Player player2;		// dealer shuffle deck and assigns 5 of the cards to player2 after player1

		
	private Card[] player1Hand; 			// Sorted cards in the hand of player 1    	 
	private Card[] player2Hand;				// Sorted cards in the hand of player 1	
	
	
	private ArrayList<Card> player1Cards;  	// ArrayList with cards of player1	
	private ArrayList<Card> player2Cards;	// ArrayList with cards of player2
	
	private int [] mycards = new int[5];	// Array of 5 integers 
	private ArrayList<Integer> cardPos = new ArrayList<Integer>(); // ArrayList for the positions of cards on the hand
	
	private int n, currTokenP1,currTokenP2;	// integer variables for a counter and tokens
	private String msg;
	private String msg1 = "Do You Want To OPEN ?";
	private String msg2 = "Use the slider to put (0-3) tokens into the pot and 'Start'";
	private String msg3 = "** Player 1 out => Computer let you win **";
	private String msg4 = "Re-Start the game if you wish on 'Start'";
	
	
	
	
	/**
	 * This method will set first messages to be displayed on Screen
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		result.setText("Welcome to Poker Game! Please click on 'Start'");
		p1Token.setText("Player 1: 10 tokens");
		p2Token.setText("Player 2: 10 tokens");
		pot.setText("Pot: 0");		
	}

	

	/**
	 * generates the displayed card for the computer hand
	 * @param event is the click on "Show Computer" button 
	 */
	public void generateCardPlay1(ActionEvent event) {
		
		try {
			cp1.setText(player1Hand[0].toString());
			cp1.setStyle(settingColor(player1Hand[0]));
			
			cp2.setText(player1Hand[1].toString());
			cp2.setStyle(settingColor(player1Hand[1]));
			
			cp3.setText(player1Hand[2].toString());
			cp3.setStyle(settingColor(player1Hand[2]));
			
			cp4.setText(player1Hand[3].toString());
			cp4.setStyle(settingColor(player1Hand[3]));
			
			cp5.setText(player1Hand[4].toString());
			cp5.setStyle(settingColor(player1Hand[4]));
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println("java.lang.NullPointerException");
			}
		}
	
	
	/**
	 * generates the displayed card for the player2 hand
	 * @param event is the click on "Show your hand" button
	 */
	public void generateCardPlay2(ActionEvent event) {
				
		cd1.setText(player2Hand[0].toString());
		cd1.setStyle(settingColor(player2Hand[0]));
		
		cd2.setText(player2Hand[1].toString());
		cd2.setStyle(settingColor(player2Hand[1]));
		
		cd3.setText(player2Hand[2].toString());
		cd3.setStyle(settingColor(player2Hand[2]));
		
		cd4.setText(player2Hand[3].toString());
		cd4.setStyle(settingColor(player2Hand[3]));
		
		cd5.setText(player2Hand[4].toString());
		cd5.setStyle(settingColor(player2Hand[4]));
		
		if (lockRound && !refresh) result.setText(msg1);
		}

	

	/**
	 * The following methods show the respective card face when 
	 * it is click on it. 
	 * That is, successive events that shows player2 hand at each time.
	 * @param event is the click on any player2 card
	 */
	public void card1_Play2(ActionEvent event) {
		try {
			cd1.setText(player2Hand[0].toString());
			cd1.setStyle(settingColor(player2Hand[0]));
			if (lockRound && !refresh) result.setText(msg1);
		} catch (Exception e) {
			System.out.println("java.lang.NullPointerException");		
			}
		}
	
	public void card2_Play2(ActionEvent event) {
		try {
			cd2.setText(player2Hand[1].toString());
			cd2.setStyle(settingColor(player2Hand[1]));
			if (lockRound && !refresh) result.setText(msg1);
		} catch (Exception e) {
			System.out.println("java.lang.NullPointerException");		
			}
		}
	
	public void card3_Play2(ActionEvent event) {
		try {
			cd3.setText(player2Hand[2].toString());
			cd3.setStyle(settingColor(player2Hand[2]));
			if (lockRound && !refresh) result.setText(msg1);
		} catch (Exception e) {
			System.out.println("java.lang.NullPointerException");		
			}
		}
	
	public void card4_Play2(ActionEvent event) {
		try {
			cd4.setText(player2Hand[3].toString());
			cd4.setStyle(settingColor(player2Hand[3]));
			if (lockRound && !refresh) result.setText(msg1);
		} catch (Exception e) {
			System.out.println("java.lang.NullPointerException");		
			}
		}
	public void card5_Play2(ActionEvent event) {
		try {
			cd5.setText(player2Hand[4].toString());
			cd5.setStyle(settingColor(player2Hand[4]));
			if (lockRound && !refresh) result.setText(msg1);
		} catch (Exception e) {
			System.out.println("java.lang.NullPointerException");		
			}
		}
	

	/**
	 * Method that set card colors red for diamond and heart, black otherwise.
	 * @param card
	 * @return
	 */
	public String settingColor(Card card) {
		
		if (card.getSuit().equalsIgnoreCase("H") || card.getSuit().equalsIgnoreCase("D")) {
			return "-fx-text-fill: red; -fx-background-image:none;-fx-background-color:white ";
		}	
		return "-fx-text-fill: black; -fx-background-image:none; -fx-background-color:white ";
	}
	

	
	/**
	 * Method that reset card layout and set the "face-down" layout.
	 * @param card
	 * @return
	 */
	public void resetCards() {
		
	    String faceDown ="-fx-background-image: url('application/bkg2.png');"
	    + "-fx-background-size: contain;"
	    + "-fx-background-repeat: no-repeat;"
	    + "-fx-background-position: center;";

	    cd1.setText("");cd2.setText("");cd3.setText("");
	    cd4.setText("");cd5.setText("");
	    
	    cp1.setText("");cp2.setText("");cp3.setText("");
	    cp4.setText("");cp5.setText("");

	    cd1.setText("");cd2.setText("");cd3.setText("");
	    cd4.setText("");cd5.setText("");
	    
	    cp1.setText("");cp2.setText("");cp3.setText("");
	    cp4.setText("");cp5.setText("");

	    cd1.setStyle(faceDown);cd2.setStyle(faceDown);cd3.setStyle(faceDown);
	    cd4.setStyle(faceDown);cd5.setStyle(faceDown);
	    
	    cp1.setStyle(faceDown);cp2.setStyle(faceDown);cp3.setStyle(faceDown);
	    cp4.setStyle(faceDown);cp5.setStyle(faceDown);

	    cd1.setStyle(faceDown);cd2.setStyle(faceDown);cd3.setStyle(faceDown);
	    cd4.setStyle(faceDown);cd5.setStyle(faceDown);
	    
	    cp1.setStyle(faceDown);cp2.setStyle(faceDown);cp3.setStyle(faceDown);
	    cp4.setStyle(faceDown);cp5.setStyle(faceDown);
	}

	
	
	/**
	 * Method that checks the answer for the requested question
	 * covers two buttons "Yes" and "No"
	 * @param event
	 * @throws Exception 
	 */
	public void answer(ActionEvent event) throws Exception {
		
		//take the String value for the button that is clicked.
		String value = ((Button)event.getSource()).getText();
		
		/* 
		 * after first question "Do you want to open?"
		 * this comes after startGame() and lockRound=true.
		 *  
		 * The series of boolean variables are to help to avoid user to click on
		 * other buttons for instance to avoid click on "Refresh hands" button
		 * and click on "Start" nothing will happen. For this
		 * lockRound=true; foldQuestion=false; refresh=false;
		 * */
		
		if (value.contentEquals("Yes")&&lockRound&&!foldQuestion&&!refresh) {
			result.setText("Refresh your hands");
			topFirstOpen();
			System.out.println("called topFirstOpen after Yes");			
			}
		
		/* 
		 * after second question for player 2 if want to proceed to open the hand
		 * foldQuestion=true; roundEnd=false; 
		 * Send a message about the tokens to place. 
		 */
		else if (value.contentEquals("Yes") && foldQuestion && !roundEnd) {
			result.setText(msg2);
			}

		/* 
		 * after the question for player 2 if wish to refresh the hands
		 * lockRound=true; roundEnd=true;
		 * 
		 */
			
		else if (value.contentEquals("Yes") && lockRound && roundEnd) {
			topFirstOpen();
			roundEnd=false;
			result.setText("Refresh your hands");
			System.out.println("after a full round");
			}

		/* 
		 * after the question for player 2 if wish to open
		 * lockRound=false; foldQuestion=true;
		 * 
		 */
		else if (value.contentEquals("No") && foldQuestion) {
			lockRound = false; // allow to restart
			player2Folds();
			foldQuestion=false; // resetting the refresh and doesn't allow "Yes" option, only 'Start'
			previousTokens=true;
			result.setText(msg4);
			}

		/* 
		 * This to avoid "No" activation during player2 pickup cards
		 * foldQuestion=false;
		 * 
		 */		
		else if (value.contentEquals("No") && !foldQuestion) {  
			}
		
		/* 
		 * If player 2 after fold or don't want to open in either stage
		 * displays message to click on "Start" if player wants to
		 * player again.
		 * 
		 */						
		else if (value.contentEquals("No") && lockRound) {
			result.setText(msg4);
			lockRound=false;
		}
	}
	

	
	/**
	 * This method initiate the game by checking if the both hands are qualified to start/open
	 * 
	 * @param event is click on "Start" button.
	 */
	public void startGame(ActionEvent event)  {
		
		
		/*  PLAYER1 => COMPUTER		PLAYER2=> YOU */
		
		while (!lockRound) { // not allow to run until lockRound is false

			result.setText("New Game");
			resetCards();
			player2CanWant=false;
			player1CanWant=false;

			
			System.out.println("----------------------------------------------");
			try {
	
				System.out.print("players can open: ");
				System.out.println(player2CanWant && player1CanWant);
				
				do {		// loop to guarantee both hands are qualified
				
					dealer = new PokerDeck();					
					
					player1 = new Player(dealer.getCards(5));	
					player2 = new Player(dealer.getCards(5));
	
													
					//Sorting the cards in the hand
					player1Hand = Deck.sort(player1.getHand());    	 
					player2Hand = Deck.sort(player2.getHand());		
					
			
					/* PLAYERS NEED TO CHECK IF THEY CAN AND WANT TO OPEN. 
					TO OPEN YOU HAVE TO HAVE BETTER THAN A PAIR OF JACKS*/
					
					if (Player.canOpen(player1) && Player.canOpen(player2)) {
						player1CanWant = true; player2CanWant = true;
	
							// PLAYERS NEED TO SEE THE OWN HANDS		
							System.out.println(Utility.printHands("Player 1: ", player1Hand));
							System.out.println(Utility.printHands("Player 2: ", player2Hand));
							
							}
				
					} while (!(player2CanWant && player1CanWant)); // END OF QUALIFY HAND LOOP
				
				System.out.print("players can open: ");
				System.out.println(player2CanWant && player1CanWant);
				
				}

				catch (Exception e) {
					System.out.println(e);
					} 

				msg = "Check your cards";
				result.setText(msg);
		
				lockRound=true;		// this lock this event until lockRound is false again.
				refresh = false; 	// setting it false because it did not reach that stage
				
				System.out.println ("Got qualified hands!");
				//System.out.println("deck size after the round:\t"+dealer.getDeckStack().size());
			}
		} 
	

	
	/**
	 * Method when it is called set the tokens to the players
	 * It check if it is the first time play or it is another game.
	 * If it is not the first game, it does set the next game with
	 * the tokens won or lost from the previous game.
	 * It can throw Exception if any of the players does not have
	 * enough tokens. 
	 * 
	 * @throws Exception
	 */
	public void topFirstOpen() throws Exception {

		if (lockRound) {
			// IF THE GAME IS OPENED EACH PLAYER MUST TOP ONE TOKEN					

			if (roundEnd || previousTokens) {	// if it comes from an previous round
				player1.setToken(currTokenP1);
				player2.setToken(currTokenP2);
				System.out.print("previousTokens ");
				System.out.println(previousTokens);
				}

			
			player1.putToken(1);		// player1 taking one token from his own
			player2.putToken(1);		// player2 taking one token from his own
			dealer.setPot(2);			// dealer placing two tokens into game pot
			
			
			System.out.println("inside "+foldQuestion);
			p1Token.setText("Player 1: "+player1.getToken());
			p2Token.setText("Player 2: "+player2.getToken());
			pot.setText(""+dealer.getPot());
				
			Utility.tokenOutput(dealer, player1, player2);
		}
		
	}
	
	
	/**
	 * Method that is called if both players want to open and
	 * refresh the hands.
	 * 	
	 */
	public void playGame()   {
		
		
	try {	
		System.out.println("refresh is called");
		
		refresh = true;
		
		String value = result.getText();
	
		//confirming if the game is to open
		if (value.equalsIgnoreCase("Refresh your hands")) {  
		
			// if it comes from an previous round
			if (roundEnd) {	
				player1.setToken(currTokenP1);
				player2.setToken(currTokenP2);
				}
					
			// Display the tokens in the screen
			p1Token.setText("Player 1: "+player1.getToken());
			p2Token.setText("Player 2: "+player2.getToken());
			pot.setText(""+dealer.getPot());
				
			Utility.tokenOutput(dealer, player1, player2);
	
			
			/* HERE WHERE EACH ONE OF THE PLAYERS CHOOSE WHAT CARDS TO DISCARD */
			
			// PLAYER1 AS computer uses AUTOMATIC SELECTION
			System.out.println("Cards to keep on hand");
			
			player1Cards = PokerDeck.wantTokeep(player1Hand);
			System.out.println("Player1: "+player1Cards.toString());
			System.out.println();
			
			
			player1Hand = Deck.sort(Player.refresh(dealer,player1Cards));
			
			System.out.println(Utility.printHands("Player 1 new hand:\n ", player1Hand));
	
			
			/* Display the new refreshed hand for computer
			 * generateCardPlay1(null);
			 * Resetting the computer hand display, or turn off the face values
			 */
			resetCards();
			
			//automatic selection if it is checked
			if (checkBox.isSelected()) { 
	 			player2Cards = PokerDeck.wantTokeep(player2Hand); 
				player2Hand = Deck.sort(Player.refresh(dealer,player2Cards));
				System.out.println(Utility.printHands("Player 2 new hand:\n ", player2Hand));
				
				// Display the new refreshed hand for player2
				generateCardPlay2(null);
				
				result.setText("Player 2, do you want to open ?");
				foldQuestion = true; 
				// now player should answer the question on the event "Yes" or "No" with foldQuestion=true; 
	 			}
			// player 2 want to select cards
			else { 
				result.setText("Player 2, please select at leats one card that you want to keep and refresh");
				for (int i=0; i<mycards.length; i++) mycards[i]=0;				
				}
			
			} // end of the first if
			
		// comparing if the message displayed is the expected one
		else if (value.equalsIgnoreCase("Player 2, please select at leats one card that you want to keep and refresh")){
				player2();
				}
		// comparing if the message displayed is the expected one
		else if (value.equalsIgnoreCase("Player 2, select at least one card and refresh")){
			player2();
			}

		System.out.print("foldQueston: ");
		System.out.println(foldQuestion);
	}
	// reseting the tokens to initial value if one or both does not have enough tokens to proceed a new round.
	catch(Exception e) {
		result.setText("One or both of players don't have enough tokens to play. Start all over again");
		startGame(null);
		p1Token.setText("Player 1: "+10);
		p2Token.setText("Player 2: "+10);
		pot.setText("Pot: "+0);
		player1.setToken(10);
		player2.setToken(10);
	}	
}
	
	/**
	 * Method called when player 2 decides to choose the cards to keep on the hand.
	 * 
	 */
	public void player2() 	throws Exception  {
		
		int ncards =0;		//initialise the local variable
		
		cardPos.removeAll(cardPos); // empty the arraylist
		
 			System.out.println("The cards are at positions 1,2,3,4 and 5");
 			msg = "Please select the card position";
 		
 			//loads the card position that player 2 want to keep
 			if (cbc1.isSelected()) cardPos.add(1);
 			if (cbc2.isSelected()) cardPos.add(2);
 			if (cbc3.isSelected()) cardPos.add(3);
 			if (cbc4.isSelected()) cardPos.add(4);
 			if (cbc5.isSelected()) cardPos.add(5);
 			
 			ncards= cardPos.size();
			
 			if (ncards==0) result.setText("Player 2, select at least one card and refresh");
 			
 			else {
 			
	 			mycards = new int[ncards];
		 			
	 			for (int i=0; i<ncards; i++) mycards[i]= cardPos.get(i);
		 			
	 			for (int i=0; i<ncards; i++) System.out.println(mycards[i]);
		 			
	 			player2Cards = Player.keepMyCards(player2Hand, mycards);
		
	 			System.out.println("Player2: "+player2Cards.toString());
	 			System.out.println();
				
		 		// REFRESH THE HANDS AND SHOW TO THE RESPECTIVE PLAYER
				
				player2Hand = Deck.sort(Player.refresh(dealer,player2Cards));
				System.out.println(Utility.printHands("Player 2 new hand:\n ", player2Hand));
		
				generateCardPlay2(null);
				
				cbc1.setSelected(false);cbc2.setSelected(false);cbc3.setSelected(false);
				cbc4.setSelected(false);cbc5.setSelected(false);
				
				System.out.println("deck size after refresh:\t"+dealer.getDeckStack().size());
		
				// after showing the new hand player 2 is questioned
				result.setText("Player 2, do you want to open ?");
				
				foldQuestion = true;
 			}		
	}
	
	
	/**
	 * Method that is called when the player 2 decides to fold
	 * Manage the tokens for each player for this situation. Also,
	 * send the values to the game board.
	 * 
	 * @throws Exception
	 */
	
	public void player2Folds() throws Exception {
		
		Utility.tokenOutput(dealer, player1, player2);
		
		currTokenP1= player1.getToken()+dealer.getPot();
		currTokenP2= player2.getToken();
		dealer.resetPot();
		
		p1Token.setText("Player 1: "+currTokenP1);
		p2Token.setText("Player 2: "+currTokenP2);
		pot.setText(""+dealer.getPot());
		
	}
	
		

	/**
	 * This method will get the value of the tokens that Player 2
	 * wants to bet and put into Pot. Then, the game is continue
	 * to play. Also, it will only executed after player2 refreshed hand, 
	 * i.e. foldQuestion=true
	 * 
	 * It is called when the slider is click on
	 * 
	 * @throws Exception 
	 */
	
	@FXML
	public void setBet() throws Exception{
		
		// this avoid any previous values from slider (constantly listening)
		if (foldQuestion && !roundEnd) { 
		
			n = (int) slider.getValue(); 

			result.setText(n+"");
			
			System.out.println("number of tokens: "+n);
			
			afterBetting(); // this finally gives the result of the game
		}
		System.out.println("play around the slider");
	}
	
	/**
	 * Method that is called after the bet is placed, i.e., after the slider
	 * is used and variable foldQuestion=true.
	 * 
	 * @throws Exception
	 */
	public void afterBetting() throws Exception {
	
			
		player2.putToken(n);
		dealer.setPot(n);// n tokens are removed from player and put into the pot
		p2Token.setText(""+player2.getToken());		
			
		//COMPUTER WANTS TO SEE
			
		if ((int)(Math.random()*2) == 1 ){ 
				
			System.out.println("** computer want to see your hand **");
			result.setText("** computer want to see your hand **");	
			
			System.out.println();

			 // compute matches your bet
			player1.putToken(n);
			p1Token.setText(""+player1.getToken());
		
			// n tokens are removed from player and put into the pot
			dealer.setPot(n);	
			pot.setText("Pot: "+dealer.getPot());

			System.out.println("After betting:");
			Utility.tokenOutput(dealer, player1, player2);
			p1Token.setText("Player 1: "+player1.getToken());
			p2Token.setText("Player 2: "+player2.getToken());
			pot.setText("Pot: "+dealer.getPot());

			
			System.out.println();
				
			//get two hands evaluated after "seeing"				
			String result1=PlayPoker.game(player1Hand, player2Hand);

			//setting the tokens
			if(result1.contains("PLAYER 1 wins")) player1.topUpToken(dealer.getPot());								
			else player2.topUpToken(dealer.getPot());

			System.out.println(">>> "+result1+" <<<\n");
			result.setText(">>> "+result1+" <<<");	
			dealer.resetPot();
			
			p1Token.setText("Player 1: "+player1.getToken());
			p2Token.setText("Player 2: "+player2.getToken());
			pot.setText(""+dealer.getPot());
			
			roundEnd=true;
			}
	
			//computer don't want to see and let you win
			else {
				System.out.println();
				System.out.println(msg3);
				System.out.println();
				result.setText(msg3);

				//player 2 take the tokens
				player2.topUpToken(dealer.getPot());
				dealer.resetPot();

				p1Token.setText("Player 1: "+player1.getToken());
				p2Token.setText("Player 2: "+player2.getToken());
				pot.setText("Pot: "+dealer.getPot());
				
				roundEnd=true;
				}
		
		System.out.println("After results:");
		Utility.tokenOutput(dealer, player1, player2);
		currTokenP1= player1.getToken();
		currTokenP2= player2.getToken();
		lockRound = false; // to allow to restart a new game/round
		System.out.println("deck size after the round:\t"+dealer.getDeckStack().size());
		System.out.println();
	
		}
	}

