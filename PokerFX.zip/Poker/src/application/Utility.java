package application;

import java.util.Scanner;

import javax.swing.JOptionPane;

/**
 * This class has general static methods that are called to give support to the driver class.
 *  
 * @author Denisio
 *
 */
public class Utility {

	/**
	 * Method to print out the cards on the hand
	 * @param msg
	 * @param hand
	 * @return String of cards sequence with the respective value and suit
	 */
	public static String printHands(String msg, Card [] hand) {
		String result="";
		for (int i=0; i<hand.length; i++) result+=hand[i]+" ";
		return (msg+""+result);
	}

	/**
	 * Method "question" takes a String msg and with the question and return true or false
	 * if the answer is 'y' or 'n'. If none of the proper answer is inputed the question is
	 * repeat until one of the options are right.  
	 * 
	 * @param String msg
	 * @return true if the input value is 'y' or 'Y' or false if 'n' or 'N'.
	 */
	public static boolean question(String msg) {
    	Scanner sc= new Scanner(System.in); 	// creating scanner object
    	System.out.print(msg+"(Y/N)?\t");
		Character choice=Character.toLowerCase(sc.next().charAt(0));
		System.out.println();
		 
		// Ensuring that only accepts valid options
		while (choice!='y'&&choice!='n') {
		   	System.out.print("Enter a valid answer (Y/N)\t");
		   	choice=Character.toLowerCase(sc.next().charAt(0));
		   	System.out.println();
		    }
    	
		if (choice=='y') return true;
		else return false;
    };

    /**
     * Method "numQuestion" takes two parameters, a String msg with the question,
     * and an int upBound that limit the maximum value for the choice for the input value.
     * The method will repeat for input cases different from the requested range 0 to upBound.
     *    
     * @param Strin msg 
     * @param int upBound
     * @return a number from 0 to upBound
     */
	public static int numQuestion(String msg, int upBound) {
    	int choice;
    	Scanner sc= new Scanner(System.in); 	// creating scanner object
    	System.out.print(msg+"\t");
    	
    	do {
    	try {
    		choice=Integer.parseInt(sc.next());
    		}
    	catch (NumberFormatException anError) {
            choice= -1;
            }
    	if (choice<0 || choice>upBound)System.out.println("not right, try again");
    	}while (choice<0 || choice>upBound); 
    	
		return choice;
    };
	
    /**
     * method overloaded "question" takes two String parameters and waiting for a input value
     * if the answer is 'y' or 'Y' returns true otherwise false. 	
     * @param player
     * @param msg
     * @return true if the input value for the answer is 'y' or 'Y', otherwise false.
     */
	public static boolean question(String player, String msg) {
		
		String answer = null;
		boolean result;
		
		
		try{
			answer = JOptionPane.showInputDialog(null,msg+player+" ?");
			

			if (answer.equalsIgnoreCase("y")) result = true;
			else result = false;
			
		}
		catch(Exception e) {
			result=false;
			}
		return result;
	}
	
	/**
	 * method numberMsg to ask how much to bet
	 * @param msg
	 * @return the number of tokens to put into the pot
	 */
	public static int numberMsg(String msg) {
		return Integer.parseInt(JOptionPane.showInputDialog(null,msg));
	}
		

	/**
	 * method tokenOutput outputs the tokens quantities for the players and from the pot.
	 * It will throws an Exceptions if one of the players does not have funds enougth to play.
	 * 
	 * @param PokerDek dealer
	 * @param Player player1
	 * @param Player player2
	 * @throws Exception
	 */
	public static void tokenOutput(PokerDeck dealer, Player player1, Player player2) throws Exception {
		System.out.println("How much in the pot?\t"+dealer.getPot());
		System.out.println("how much player1 has:\t"+player1.getToken());
		System.out.println("how much player2 has:\t"+player2.getToken());
		System.out.println();
			
	}
		
		
    
	
	
}
