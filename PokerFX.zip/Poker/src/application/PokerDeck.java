package application;

import java.util.ArrayList;
import java.util.Collections;

/**
 * PokerDeck is the derive class from Deck. This class besides to have the methods
 * from the base class, the instance can call the methods specific for the Poker game, which  are:
 * 
 * boolean isflush(Card [] hand);
 * boolean isStraight(Card [] hand);
 * isThereTriplet(Card [] hand);
 * isTherePairs(Card [] hand);
 * int score(Card [] hand);
 * int getPot();
 * void resetPot()
 * int isThereAnyOfKind(Card [] hand)
 * Card maxCardValue(Card [] hand)
 * ArrayList<Card> wantTokeep(Card [] hand)
 * 
 * 
 * It also set the 'pot' for the game where the bets are placed by the players.
 * 
 *  
 * @author Denisio
 *
 */

public class PokerDeck extends Deck{

	private int pot;

	
	/**
	 * method getPot return to the caller the current value in the pot
	 * 
	 * @return pot is the value in the pot
	 */
	public int getPot() {
		return pot;
	}
	
	
	/**
	 * method resetPot is a procedure that when call, reset the pot value to 0. 
	 */
	public void resetPot() {
		pot=0;
	}
	
	
	/**
	 * method setPot will add a token value passed by the caller into the pot.
	 *  
	 * @param token is the value added into the pot
	 */
	public  void setPot(int token) {
		pot+=token;
	}

	/**
	 *  Method "isflush" return true if there is flush (5 cards with the same suit).
	 *  Returns false if not. 
	 *  
	 *  @parameter: Card [] hand 
	 *  @return:	true if there is flush and false otherwise
	 */
	public static boolean isFlush(Card [] hand) {
		boolean key = false;
		String temp = hand[0].getSuit();		// taking the first card suit to start the comparison
		for (int i=1; i<hand.length;i++) {
			if (temp.equals(hand[i].getSuit())) // if the previous suit is equal to current suit
				key = true;						// the key is true, otherwise returns false.
			else return false;
			temp = hand[i].getSuit();			// assigning the current suit as previous
			}									// and continue the loop
		return key;								// return true if all are the same.
		}

	/**
	 *  Method "isStraight" return true if there is all the cards are in a sequence 
	 *  that differs of one unit of face value.  Returns false if not. 
	 *  Note that Ace, 2, 3, 4, 5 is a Straight sequence with Ace at short end. This
	 *  is taking account in this method, by recognizing also 10,J,Q,K,Ace as the other end.
	 *  
	 *  @parameter: Card [] hand 
	 *  @return:	true if there is flush and false otherwise
	 */
	public static boolean isStraight(Card [] hand) {
		boolean key=true;
		int n=hand.length;									// number of cards in hand
		int a,b,c,d;
		c =Integer.parseInt(replacement(hand[n-2]));		// integer value of one before last card
		d =Integer.parseInt(replacement(hand[n-1]));		// integer value of last card
	
		for (int i=1;i<n-1;i++) {
			a = Integer.parseInt(replacement(hand[i-1])); 	// integer value of previous card
			b = Integer.parseInt(replacement(hand[i])); 	// integer value of current card			
			if (b-a==1 && d-c==1 || b-a==1 && d-c==9){      // the difference by 9 is to consider Ace
															// at the other end of sequence.
				key&=true;
				}
			else return false;
			}				
		return key;
		}

	
	/**
	 *  Method "isThereAnyOfKind" is a method that check if there are face value replica on the hand,
	 *  and return a number corresponding to the repetition.
	 *  
	 *  @parameter: Card [] hand 
	 *  @return:	4 if there are 4 four of kinds, 3 for triplets,
	 *  			2 for two pairs and 1 for one pair, and 0 for no replica.
	 */
	public static int isThereAnyOfKind(Card [] hand) {
		ArrayList<String> list = new ArrayList<String>();	// creates a ArrayList list to store the cards				
		for (int i=0; i<hand.length; i++) {					// Adding the cards values to the list
			list.add(hand[i].getValue());
			}
		int count=0;
		// using the frequency method of Collections to check if there is a card value repeats 3 times.
		for (int i=0; i<hand.length; i++) {
			if (Collections.frequency(list, hand[i].getValue())==4) return 4;
			if (Collections.frequency(list, hand[i].getValue())==3)	return 3;
			if (Collections.frequency(list, hand[i].getValue())==2) {
				count++;									// this counts double because of repeated
				}											// element in pairs. need to divide by 2.
			}			
			if (count/2==2) return 2;
			if (count/2==1) return 1;
		return 0;
		}	

	

	/**
	 *  Method "isTherePairs" return an integer that indicates if there is one pair,
	 *  two pairs or none in the cards.

	 *  @parameter: Card [] hand 
	 *  @return:	2 if there two pairs, 1 if there is a pair, and 0 for none
	 */
	public static int isTherePairs(Card [] hand) {
		
		ArrayList<String> list = new ArrayList<String>();	// creates a ArrayList list to store the
															// cards
		// Adding the cards values to the list
		for (int i=0; i<hand.length; i++) {
			list.add(hand[i].getValue());
			}
		
		int count=0;
		for (int i=0; i<hand.length; i++) {
			if (Collections.frequency(list, hand[i].getValue())==2) {
			//	pairValue = Integer.parseInt(replacement(hand[i]));
				count++;									// this count counts double because of repeated
				}											// element in pairs. need to divide by 2.
			}
		if (count/2==1) return 1;
		if (count/2==2) return 2;
		return 0;
		}
	
	
	/**
	 *  Method "isThereTriplet" return true if there are three cards with the same face value.
	 *  Returns false if not.
	 *  
	 *  @parameter: Card [] hand 
	 *  @return:	true if there is Triplet and false otherwise
	 */
	public static boolean isThereTriplet(Card [] hand) {
		ArrayList<String> list = new ArrayList<String>();	// creates a ArrayList list to store the
															// cards
		// Adding the cards values to the list
		for (int i=0; i<hand.length; i++) {
			list.add(hand[i].getValue());
			}
		// using the frequency method of Collections to check if there is a card value repeats 3 times.
		for (int i=0; i<hand.length; i++) {
			if (Collections.frequency(list, hand[i].getValue())==3) return true;
			}
		return false;
		}
	
	
	
	
	/**
	 *  Method score that returns the scores of the repeat cards in hand array
	 *  It takes all the card values in hand and add them, and returning
	 *  the result.
	 *  
	 *  @parameter:  Card [] hand
	 *  @return:	int score. 
	 */
	public static int score(Card [] hand) {
		
		ArrayList<Card> list = wantTokeep(hand);
		 
		hand = list.toArray(new Card[list.size()]);  
	        
		int score=0, n=hand.length;
		for (int i=0;i<n;i++) score+= Integer.parseInt(replacement(hand[i])); 
		return score;
		}
				

	/**
	 * Method that evaluates the hand and return the high value card. Ace as 14.
	 * @param hand
	 * @return Card with maximum face value.
	 */
	public static Card maxCardValue(Card [] hand) {
		int max, index = 0, n=hand.length;
		max= Integer.parseInt(replacement(hand[0]));
		for (int i=1;i<n;i++) {
			if (max<Integer.parseInt(replacement(hand[i]))) {
				max=Integer.parseInt(replacement(hand[i]));
				index=i;
				}
			}
		return hand[index];
		}

	
	/**
	 *  Method "wantTokeep" return a list of card that player wants to keep on the hand after
	 *  open the game. It is an automatic selection for the computer and available for the player.
	 *  
	 *  @parameter: Card [] hand 
	 *  @return:	ArrayList<Card> of the cards that player want to keep.
	 */
	public static ArrayList<Card> wantTokeep(Card [] hand) {
		ArrayList<String> list = new ArrayList<String>();	// creates a ArrayList list to store the card values
		ArrayList<Card> myHand = new ArrayList<Card>();
		ArrayList<Card> myHand0 = new ArrayList<Card>();   	// for hands with no rank

		for (int i=0; i<hand.length; i++) {					// Adding the cards values to the list
			list.add(hand[i].getValue());
			}
		
		boolean triplet = false, pair =false;

		// using the frequency method of Collections to check if there is a card value repeats 3 times.
		
		for (int i=0; i<hand.length; i++) {
			
			if (Collections.frequency(list, hand[i].getValue())==4) { 		//it stores 4 times in myHand 
				myHand.add(hand[i]); 				
				}
			else if (Collections.frequency(list, hand[i].getValue())==3) { 	//it stores 3 times in myHand
				myHand.add(hand[i]);
				triplet=true;
				}
			else if (Collections.frequency(list, hand[i].getValue())==2) { 	// it stores 2 times if one pair or 4 times if two pairs
				myHand.add(hand[i]);
				pair =true;
				}
			else  
				myHand0.add(hand[i]); 								//add any card without duplication, 1 card (four replicas or 2 pairs),
			}														// 2 cards (triplets), or 3 cards (one pair) or 5 cards (all different) 
		if (myHand0.size()==5) {
			if (PokerDeck.isFlush(hand) || PokerDeck.isStraight(hand))return myHand0;
			else if (triplet && pair) return myHand;				// return a full house
			else { 
				myHand0.removeAll(myHand0);
				myHand0.add(maxCardValue(hand)); 					// only the high face value card is returned
				return myHand0;
				}
			}
		else if (myHand0.size()==3) return myHand;					// return one pair
		else if (myHand0.size()==2) return myHand;					// return a triplet
		else 
			return myHand;											// return two pairs or four of kind
		
	}
}