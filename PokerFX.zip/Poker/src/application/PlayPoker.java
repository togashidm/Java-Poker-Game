package application;

/*
 * The "PlayPoker" class is derived class from PokerDeck where the two hands are compared to each other by the following rules:
 * 
 * 	�	A royal flush (a straight flush starting at Ace and going down through King, Queen, Jack, to Ten)
 *	�	A straight flush (a straight but all in the same suit � the higher the better)
 *	�	Four of a kind (the higher the better)
 *	�	A flush (all the same suit - the higher the better)
 *	�	A straight (for example �4 clubs, 5 spades, 6 clubs, 7 diamond, 8 spades� - the higher the better)
 *	�	A full house (triplets and a pair - the higher the triplets, the better)
 *	�	Triplets (the higher the better)
 *	�	2 pairs (the higher the better)
 *	�	1 pair (the higher the better) 
 *
 * 	The "higher the better" is determined by the scores that on player's hand has against the other. 
 * 
 * 
 * @author Denisio
 *
 */
public  abstract class PlayPoker extends PokerDeck{


	public static String game(Card [] player1, Card [] player2) {
		String message = null;
		String msg1 = "wins by Royal flush";
		String msg2 = "wins by Straight-Flush";
		String msg3 = "wins by Four of kind";
		String msg4 = "wins by Flush";
		String msg5 = "wins by Straight";
		String msg6 = "wins by FULL HOUSE";
		String msg7 = "wins by Triplets";
		String msg8 = "wins by 2 PAIRS";
		String msg9 = "wins by 1 PAIR";
		
		
		//checking for flush
		if (isFlush(player1)==true && isFlush(player2)==false) 
			message="PLAYER 1 "+msg4;
			
		else if (isFlush(player2)==true && isFlush(player1)==false) 
			message="PLAYER 2 "+msg4;
			
		//when both has a Flush. Checking for Straight
		else if (isFlush(player1)==true && isFlush(player2)==true) {
			if(isStraight(player1)==true && isStraight(player2)==false) 
				message="PLAYER 1 "+msg2;
				
			else if(isStraight(player2)==true && isStraight(player1)==false) 
				message="PLAYER 2 "+msg2;
				
			//when both has a flush and straight. checking the high score
			else if(isStraight(player1)==true && isStraight(player1)==true) {
				
				if(score(player1) > score(player2)) {
					if (score(player1)==60) message="PLAYER 1 "+msg1;
					else message="PLAYER 1 "+msg2 +" and scores: "+score(player1)+" vs "+score(player2);					
					}
				
				else if(score(player2) > score(player1)) {
					if (score(player2)==60) message="PLAYER 2 "+msg1;
					else message="PLAYER 2 "+msg2 +" and scores: "+score(player2)+" vs "+score(player1);					
					}
					
				else message="TIE"+score(player2)+" vs "+score(player1);
				
				}// end of having flush and straight
			
			//when both has flush but not straight. They can NOT have duplicates
			else {
				if(score(player1) > score(player2)) {
					message="PLAYER 1 "+msg4+" and scores: "+score(player1)+" vs "+score(player2);
					}
				else if(score(player2) > score(player1)) {
					message="PLAYER 2 "+msg4+" and scores: "+score(player2)+" vs "+score(player1);
					}
				else message="TIE\t"+score(player1)+" vs "+score(player2);
				}
			}// end of having flush and not straight
		
		//when both does not have a Flush. Checking for Straight and repetition	
		else {
			if(isStraight(player1)==true || isStraight(player2)==true) {
				
				if (isStraight(player1)==true && isStraight(player2)==false) 
					message="PLAYER 1 "+msg5;
					
				else if (isStraight(player2)==true && isStraight(player1)==false) 
					message="PLAYER 2 "+msg5;
					
				//when both don't have a flush and but both having straight. They can't have duplicates
				else if (isStraight(player1)==true && isStraight(player2)==true){
					
					if(score(player1) > score(player2)) 
						message="PLAYER 1 "+msg5+" and scores: "+score(player1)+" vs "+score(player2);
						
					else if(score(player2) > score(player1)) 
						message="PLAYER 2 "+msg5+" and scores: "+score(player2)+" vs "+score(player1);
						
					else message="TIE"+score(player2)+" vs "+score(player1);
					}
				}//end of not a flush and but a straight
		
			//when both don't have a flush and don't have straight. Checking repetitions
			else {
				
				// for Triplets
				if(isThereTriplet(player1)==true && isThereTriplet(player2)==false) 
					if (isTherePairs(player1)==1) message="PLAYER 1 "+msg6;
					else message="PLAYER 1 "+msg7;
				
				else if (isThereTriplet(player2)==true && isThereTriplet(player1)==false)
					if (isTherePairs(player2)==1) message="PLAYER 2 "+msg6;
					else message="PLAYER 2 "+msg7;
									
				//when both has triplets. Checking for pairs
				else if (isThereTriplet(player1)==true && isThereTriplet(player2)==true){
					
					if  (isTherePairs(player1)==1 && isTherePairs(player2)==0)  
						message="PLAYER 1 "+msg6;
						
					else if (isTherePairs(player2)==1 && isTherePairs(player1)==0) 
						message="PLAYER 2 "+msg6;
						
					//when both has triplets and pair
					else if (isTherePairs(player1)==1 && isTherePairs(player2)==1) {
						if(score(player1) > score(player2)) {
							message="PLAYER 1 "+msg6+" and scores: "+score(player1)+" vs "+score(player2);
							}
						else if(score(player2) > score(player1)) {
							message="PLAYER 2 "+msg6+" and scores: "+score(player2)+" vs "+score(player1);
							}
						else message="TIE\t"+score(player1)+" vs "+score(player2);
						}
					//when both has triplets only
					else {
						System.out.println();
						System.out.println("when both has triplets only");
						if(score(player1) > score(player2)) 
							message="PLAYER 1 "+msg7+" and scores: "+score(player1)+" vs "+score(player2);
							
						else if(score(player2) > score(player1)) 
							message="PLAYER 2 "+msg7+" and scores: "+score(player2)+" vs "+score(player1);
							
						else message="TIE\t"+score(player1)+" vs "+score(player2);
						}
					} // end of both has triplets checking for pairs
				
				//when none has triplets. Checking for 2 pairs	
				else {
					if (isTherePairs(player1) == 2 && isTherePairs(player2) < 2)   //2 vs  1 and 0
						message="PLAYER 1 "+msg8;
						
					else if (isTherePairs(player2)==2 && isTherePairs(player1) < 2) 
						message="PLAYER 2 "+msg8;
						
					// when both has 2 pairs
					else if (isTherePairs(player2)==2 && isTherePairs(player1) == 2) { 
						if(score(player1) > score(player2)) 
							message="PLAYER 1 "+msg8+" and scores: "+score(player1)+" vs "+score(player2);

						else if(score(player2) > score(player1)) 
							message="PLAYER 2 "+msg8+" and scores: "+score(player2)+" vs "+score(player1);

						else message="TIE\t"+score(player1)+" vs "+score(player2);
						}
					// when both has 1 pairs
					else if (isTherePairs(player2)==1 && isTherePairs(player1) == 1) { 
						if(score(player1) > score(player2)) 
							message="PLAYER 1 "+msg9+" and scores: "+score(player1)+" vs "+score(player2);
							
						else if(score(player2) > score(player1)) 
							message="PLAYER 2 "+msg9+" and scores: "+score(player2)+" vs "+score(player1);
							
						else message="TIE\t"+score(player1)+" vs "+score(player2);
						}
					// when one has 1 pairs
					else if (isTherePairs(player1)==1 && isTherePairs(player2) == 0)  
							message="PLAYER 1 "+msg9;
						
					else if (isTherePairs(player2)==1 && isTherePairs(player1) == 0)  
						message="PLAYER 2 "+msg9;
						
					
					// when none has triplet and no pairs - I think this is covered by both having straigths.
					else { 
						if(score(player1) > score(player2)) {
							message="PLAYER 1 WINS by scores: "+score(player1)+" vs "+score(player2);
							}
						else if(score(player2) > score(player1)) {
							message="PLAYER 2 WINS by scores: "+score(player2)+" vs "+score(player1);
							}
						else message="TIE\t"+score(player1)+" vs "+score(player2);
						}
					} //end of no triples but maybe pairs
				} //end of when both does not have straight repetition checking		
			}//end of checking for straight and repetitions
		
		//******************************************************************************
		// for four in kind
		
		
		if(isThereAnyOfKind(player1)==4 && isThereAnyOfKind(player2)!=4) {
			
			if(isFlush(player2)==true && isStraight(player2)==true) {
					if (score(player2)==60) message="PLAYER 2 "+msg1;
					else message="PLAYER 2 "+msg2;					
				}
			else message="PLAYER 1 "+msg3;
			}

		if(isThereAnyOfKind(player1)!=4 && isThereAnyOfKind(player2)==4) 
			message="PLAYER 2 "+msg3;				

		// both with four in kind
		if(isThereAnyOfKind(player1)==4 && isThereAnyOfKind(player2)==4) {

			if(score(player1) > score(player2)) {
				message="PLAYER 1 "+msg3+" and scores: "+score(player1)+" vs "+score(player2);
				}
			else if (score(player2) > score(player1)) {
				message="PLAYER 2 "+msg3+" and scores: "+score(player2)+" vs "+score(player1);
				}
			else message="TIE\t"+score(player1)+" vs "+score(player2);
			}
		//******************************************************************************					


		
		
		
		System.out.println();

		return message;
		
	}
}
