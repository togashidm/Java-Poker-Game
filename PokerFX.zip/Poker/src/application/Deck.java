package application;

/*
 * The class "Deck" shuffles and creates 52 cards deck. Any card game can use this class to create a card deck.
 * The instance from this class can call the following methods:
 * 
 * Stack<Card> getDeckStack();
 * Card[] getCards(int n);
 * Card[] sort(Card[] hand);
 * String replacement(Card hand);
 * 
 * @author Denisio
 *
 */
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Stack;


public class Deck {

	private int ncards = 52; 	// number of card in the deck
	private Card [] cards = new Card[ncards];	// array of 52 instances of Card class
	final private String [] suit = {"D","H","C","S"};
								// array suit that is initialised the the Suit labels 
	final private String [] value = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
								// array value that is initialised the card label values.
	private Stack<Card> deckStack; // Stack of instance of Card class
	
	/*
	 * Constructor Deck() that will have 52 instances of cards that are randomly shuffle
	 */
	Deck(){
		int k=0;
		// creating 52 card instances with unique value+suit
		for (int i=0; i < suit.length; i++) {
			for (int j=0; j<value.length; j++) {
				cards[k]=new Card(value[j],suit[i]);
				k++;
			}
		}
		Collection<Card> list = Arrays.asList(cards); 		// Convert to a List
        deckStack = new Stack<Card>(); 						// Create a Card stack
        deckStack.addAll(list); 							// Add all items from the List to the stack.
        Collections.shuffle(deckStack);						// Shuffle the cards
        }
	
	
	/**
	 * Method "getDeckStack" return the a Stack of cards created when the deck constructor created its instance.
	 * 	
	 * @return deckStack
	 */
	public Stack<Card> getDeckStack() {
		return deckStack;
		}


	/*
	 *  does it need a try-catch here to validate the range of n cards?
	 */
	/**
	 *  Method "getCards" takes n number of cards from the Deck stored and shuffle
	 *  in the stack and return them sorted in ascendent order of face value as an array of Card if n>1.
	 *  In only one card is inputed as parameter, it does return only just the card array.	 *  
	 *  
	 *  @parameter: int n
	 *  @return:	Card[] of sorted hand cards.
	 */
	public Card[] getCards(int n) {
		Card [] hand = new Card[n];		
		for (int i=0; i<n; i++) {		
			hand[i]= deckStack.pop();	 	// uses the method pop() to assign the top card of deckStack
			}
		return n!=1 ? sort(hand): hand;		// only call the method() sort when there is more than one card
		}

	/**
	 *  Method "sort" takes a array of Card instances and it sorts them by the face value of each card,
	 *  in ascendent order and return them sorted as an Card array.
	 *  
	 *  @parameter: Card [] hand
	 *  @return:	Card[] of sorted hand cards.
	 */
	public static Card[] sort(Card [] hand) {
		int n=hand.length;					// number of cards in hand
		Card temp;							// variable type Card
		int min,curValue;					// variable to help to sort card order
		int counter=0;
		if (n==1) counter=1;				// when there is only one card, otherwise an intermittent loop
		do {
			for (int i=1;i<n;i++) {
				min = Integer.parseInt(replacement(hand[i-1])); //first card value
				curValue=Integer.parseInt(replacement(hand[i])); //current card value
				if (curValue < min) {
					min = curValue; 		// assigning the new min
					temp=hand[i-1];			//store temp with previous card which is now smallest
					hand[i-1] = hand[i];	//exchange previous card with current card 
					hand[i]=temp;			//exchange the current card with previous card}
					counter=0;
					}
				else counter++;
				}		
			} while (counter<n);
		return hand;
		}
	
	/**
	 *  Method "replacement" replace nominal value of a card by its numerical string value, for instance,
	 *  Ace by "14". This is to help on "sort" method and verification of "Straight" hands.
	 *  
	 *  @parameter: Card hand 
	 *  @return:	the equivalent String of the card face value
	 */
	public static String replacement(Card card) {
		String cValue;
		cValue = card.getValue(); 			// takes the value by separating the card suit from value
		if (cValue.equals("J")) return "11";
		if (cValue.equals("Q")) return "12";
		if (cValue.equals("K")) return "13";
		if (cValue.equals("A")) return "14";
		return cValue;
		}
	

}
